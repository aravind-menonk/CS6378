This document details the steps to be followed:

The servers are to be run in d01, dc02 ... dc08 machines. Run the commands in the project3 directory.
Client is to be run in the dc10 machine
1. In server machines, run 
        make server 
   to run the server.

2. In client machine,
        make client
    to run the client