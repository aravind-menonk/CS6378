This document details the steps to be followed:

The server is to be run in d01 machine. Run the commands in the D1 directory.

1. In d01 machine, run 
        make server 
   to run the server.

2. In 2 other machines which are to be treated as the clients,
    2.1 run 
            make clientOne 
        in one machine  
    2.2 run 
            make clientTwo
        in the other two.